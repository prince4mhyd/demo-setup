﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using NLog.Extensions.Logging;
using Npgsql;
using System;

namespace CytelDBDeployment
{
    class Program
    {
        static void Main(string[] args)
        {
            var services = new ServiceCollection();
            ConfigureServices(services);

            using (ServiceProvider serviceProvider = services.BuildServiceProvider())
            {
                DBDeployment app = serviceProvider.GetService<DBDeployment>();
                app.Run();
            }
            
        }

        private static void ConfigureServices(ServiceCollection services)
        {
            services.AddTransient<DBDeployment>();
           
            services.AddLogging(builder =>
            {
                builder.SetMinimumLevel(LogLevel.Information);
                builder.AddNLog("nlog.config");
            });

        }
    }
}
